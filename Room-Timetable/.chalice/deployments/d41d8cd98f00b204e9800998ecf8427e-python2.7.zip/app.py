import pymysql
import sys
from chalice import Chalice
import rds_config

db_host = rds_config.db_host
db_user = rds_config.db_username
db_pass = rds_config.db_password
db_name = rds_config.db_name



app = Chalice(app_name="room_timetable")

@app.route("/")
def index():
    try:
        conn = pymysql.connect(db_host, user=db_user, passwd=db_pass, db=db_name, connect_timeout=5)
    except Exception as e:
        return ("ERROR: " + e)
    return("SUCCESS: Connection to RDS mysql instance succeeded")